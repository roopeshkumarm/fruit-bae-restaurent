const sign = document.getElementById("sign-form");

sign.addEventListener("submit",function(event){
    event.preventDefault();
    var check = true;
    const user = document.getElementById('username').value;
    const pass = document.getElementById('password').value;
    const cpass = document.getElementById('cpassword').value;

    if(pass!=cpass){
        alert("password and confirm password are not equal");
        check = false;
    }
    for(const char of user){
        if(char == '@'){
            alert("invalid username");
            check = false;
        }
    }

    

    if(check){
        localStorage.setItem('username',user);
        localStorage.setItem('password',pass);
        window.location.href="file:///C:/Users/kroop/OneDrive/Desktop/APD%20PROECT-1/fruit%20bae/login%20page.html";
    }
    else{
        alert("enter the details correctly");
    }


})