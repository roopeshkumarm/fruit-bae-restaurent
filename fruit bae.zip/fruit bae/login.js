const form = document.getElementById('login-form');

form.addEventListener('submit',function(event){
    event.preventDefault();
    const user = document.getElementById('username').value;
    const pass = document.getElementById('password').value;

    const USER = localStorage.getItem('username');
    const PASS = localStorage.getItem('password');

    if(USER === user && PASS === pass){
        window.location.href="file:///C:/Users/kroop/OneDrive/Desktop/APD%20PROECT-1/fruit%20bae/fruit%20bae.html";
    }
    else{
        alert("login credentials are incorrect");
    }
})